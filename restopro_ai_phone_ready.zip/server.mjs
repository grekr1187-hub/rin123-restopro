import "dotenv/config";
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import OpenAI from "openai";

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json({ limit: "200kb" }));
app.use(express.static(path.join(__dirname, "public")));

const SYSTEM = `
Ты RestoPro AI — сильный управляющий AI-агент для ресторанной POS-системы.
Отвечай на русском, конкретно и по делу. Анализируй цифры, находи причины,
риски и точки роста. Можешь рекомендовать и выполнять разрешённые действия
через инструменты системы в будущей версии. НИКОГДА не принимай заказы от
гостей и не оформляй заказ автономно. Не выдумывай данные: если данных нет,
скажи, что их нужно получить.
`;

app.post("/api/ai", async (req,res)=>{
  try {
    const { message, context } = req.body || {};
    if (!message) return res.status(400).json({ error:"message is required" });

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.4",
      instructions: SYSTEM,
      input: [
        { role:"user", content:[
          { type:"input_text", text:`Данные POS:\n${JSON.stringify(context || {}, null, 2)}\n\nЗапрос управляющего:\n${message}` }
        ]}
      ],
      max_output_tokens: 900
    });

    res.json({ output: response.output_text || "AI не вернул текстовый ответ." });
  } catch (err) {
    console.error("AI request failed:", err?.message || err);
    res.status(500).json({ error:"AI request failed" });
  }
});

app.get("*",(req,res)=>{
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT,()=>console.log(`RestoPro running on port ${PORT}`));
